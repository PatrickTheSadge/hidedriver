#pragma once

#define DebugMessage(x, ...) DbgPrintEx(0, 0, x, __VA_ARGS__)