#pragma once
#include <ntifs.h>

PDEVICE_OBJECT pDeviceObject;
UNICODE_STRING dev, dos;
