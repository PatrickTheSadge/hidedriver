typedef volatile long	DWORD;
typedef unsigned short	WORD;
typedef unsigned char	BYTE;